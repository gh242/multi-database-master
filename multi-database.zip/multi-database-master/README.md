# 多数据库
# 多数据库2023.08.06已经同步到最新代码，项目直接就可以使用，不用再按文档合并代码
#### 介绍
项目为Vue.NetCore框架多数据库版本，采用dotnetcore+vue+elementUI 前后端分离开发模式

#### 
- demo地址：http://www.volcore.xyz 
- 帐号admin666 密码123456
-
![Home](/h.png)  

