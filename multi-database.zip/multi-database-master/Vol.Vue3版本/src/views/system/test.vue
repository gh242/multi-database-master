<template>

</template>

<script>
export default {
  props:{
        list: {
      type: Array,
      default: [],
    },
  }
}
</script>

<style>

</style>