<template>
  <div style="text-align: center;font-size: 16px;padding: 20px;">正在加载资源...</div>
</template>
<script>
export default {
  created() {
    //  console.log('loading')
  }
};
</script>