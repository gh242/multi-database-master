import Grid from './ViewGrid.vue'
const ViewGrid = {
    install: function (app) {
        app.component('ViewGrid', Grid)
    }
}
export default ViewGrid