﻿//namespace VOL.Entity.AttributeManager
//{
//    public class DBType
//    {

//    }
//}
