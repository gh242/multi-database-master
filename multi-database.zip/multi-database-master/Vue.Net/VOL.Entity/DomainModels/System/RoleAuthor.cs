﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VOL.Entity.DomainModels
{
    public class RoleAuthor
    {
        public int menuId { get; set; }
        public string actions { get; set; }
    }
}
