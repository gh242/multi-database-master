﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VOL.Entity.DomainModels.Sys
{
   public class TableColumnInfo
    {

       public string Prec_Scale { get; set; }
       public string ColumnType { get; set; }
       public string ColumnName { get; set; }
    }
}
