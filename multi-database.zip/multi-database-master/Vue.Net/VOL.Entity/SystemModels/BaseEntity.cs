﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VOL.Entity.SystemModels
{
    public class BaseEntity
    {
    }
}
