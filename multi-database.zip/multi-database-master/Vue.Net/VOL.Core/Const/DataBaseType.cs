﻿namespace VOL.Core.Const
{
    public static class DBType
    {
        public static string Name { get; set; }
    }
}
