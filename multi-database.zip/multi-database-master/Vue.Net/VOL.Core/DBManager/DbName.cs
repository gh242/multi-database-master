﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VOL.Core.DBManage
{
    public struct DbName
    {
        public static string Default = "default";
    }
}
