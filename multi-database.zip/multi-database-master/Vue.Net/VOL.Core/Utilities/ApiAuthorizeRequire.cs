﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VOL.Core.Utilities
{
  public  class ApiAuthorizeRequire
    {
        public static void Require()
        {

        }
    }
}
