﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VOL.Core.Enums
{
    public enum QueryOrderBy
    {
        Desc=1,
        Asc=2
    }
}
