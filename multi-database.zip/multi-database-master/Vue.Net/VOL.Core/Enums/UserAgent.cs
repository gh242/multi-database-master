﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VOL.Core.Enums
{
    public enum UserAgent
    {
        IOS = 0,
        Android = 1,
        Windows = 2,
        Linux
    }
}
