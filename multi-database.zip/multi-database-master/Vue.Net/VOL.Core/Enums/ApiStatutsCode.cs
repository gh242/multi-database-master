﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VOL.Core.Enums
{
    public enum ApiStatutsCode
    {
        False = 0,
        Ok = 1,
        TokenExpire = 2

    }
}
