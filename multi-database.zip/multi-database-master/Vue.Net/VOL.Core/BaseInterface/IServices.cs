﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VOL.Core.BaseInterface
{
    public interface IServices
    {
    }
}
