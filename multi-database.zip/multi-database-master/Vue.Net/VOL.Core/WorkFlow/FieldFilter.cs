﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VOL.Core.WorkFlow
{
  public  class FieldFilter
    {
        public string Field { get; set; }
        public string Value { get; set; }

        public string FilterType { get; set; }
    }
}
