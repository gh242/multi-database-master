﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VOL.Core.WorkFlow
{
    public enum StepType
    {
        start,
        end,
        node
    }
}
