/*
*所有关于ServiceDbTest类的业务代码接口应在此处编写
*/
using VOL.Core.BaseProvider;
using VOL.Entity.DomainModels;
using VOL.Core.Utilities;
using System.Linq.Expressions;
namespace VOL.ServiceTest.IServices
{
    public partial interface IServiceDbTestService
    {
    }
 }
