﻿using System;

namespace VOL.ServiceTest
{
    public class Class1
    {
    }
}
