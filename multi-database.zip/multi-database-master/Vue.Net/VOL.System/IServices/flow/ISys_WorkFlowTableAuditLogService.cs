/*
 *代码由框架生成,任何更改都可能导致被代码生成器覆盖
 */
using VOL.Core.BaseProvider;
using VOL.Entity.DomainModels;

namespace VOL.System.IServices
{
    public partial interface ISys_WorkFlowTableAuditLogService : IService<Sys_WorkFlowTableAuditLog>
    {
    }
}
