﻿using VOL.Core.BaseProvider;
using VOL.Entity.DomainModels;

namespace VOL.System.IServices
{
    public partial interface ISys_MenuService : IService<Sys_Menu>
    {
    }
 }

