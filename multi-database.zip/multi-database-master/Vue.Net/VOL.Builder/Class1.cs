﻿using System;

namespace VOL.Builder
{
    public class Class1
    {
    }
}
