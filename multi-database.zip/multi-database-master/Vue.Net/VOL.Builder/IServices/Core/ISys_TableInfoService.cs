﻿using VOL.Core.BaseProvider;
using VOL.Entity.DomainModels;

namespace VOL.Builder.IServices
{
    public partial interface ISys_TableInfoService : IService<Sys_TableInfo>
    {
    }
 }

