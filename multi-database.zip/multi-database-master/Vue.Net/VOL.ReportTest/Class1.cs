﻿using System;

namespace VOL.ReportTest
{
    public class Class1
    {
    }
}
